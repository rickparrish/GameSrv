    Please read this information before attempting to use this revision of
    ONEFOSsil.

    Revision 9 has not changed the way ONEFOSsil operates, so old batch
    files should run fine with a simple copy-over upgrade.  However, be sure
    to check the documentation for differences, such as the Windows Tips
    section.

    Notice:  This is a quick release.  Almost every internet address stated
    in the documentation is invalid, I don't have time to correct them,
    because some internet service provider is refusing to provide me
    service, can't do anything about that, please FREQ updates from
    1:285/302 or 303 (registered version from /302 only now) or send email
    to msftrncs@htcnet.com and I'll reply with any updates.

    Revision 8 has changed how the port argument on the command line works.
    Please read ONEFOS.TXT - Installing - Port Argument for more
    information.  If you fail to read the documentation, ONEFOSsil Revision
    8 will not function in old batch files.

    Please read ONEFOS.TXT - Compatibility Notes about compatibility
    problems with some programs!  It also covers eliminating CRC errors
    under Windows, along with other useful tips.

    ONEFOSsil is not yet complete.  It is however quite useful in its
    current form.  Please be sure to read the documentation, it has changed.

    ONEFOSsil supports most of the FOSSIL 5 specification with exceptions to
    carrier watchdogs, timer chaining, and extension functions.  These
    functions are rarely used with modern IBM PC software.  ONEFOSsil also
    supports many of the X00 advanced functions.  ONEFOSsil also has some
    (very few) extensions of its own.  This information is contained in the
    file ONEREF.TXT now distributed with ONEFOSsil.

    If you have trouble using ONEFOSsil, read ONEFOS.TXT - Troubleshooting
    to see if your problems can be solved there, else read SUPPORT.TXT on
    how to receive support.

    The latest version of ONEFOSsil is available by File REQuest from
    1:285/302@FidoNet as "ONEFOS".  The latest version plus other related
    files may be found on the Internet at: ftp://members.aol.com/kiwi7416 or
    at http://home.aol.com/kiwi7416.  You may also call Hooper Connections
    BBS at (402) 654-2102 (V.34) and download ONEFOSsil on your first call.
    Another place ONEFOSsil information can be found on the Internet is at
    http://htcnet.com/~msftrncs/products/onefossil/index.html.

    You may have already noticed that ONEFOSsil's archive is Windows
    friendly.  All documentation files have an extension of .TXT rather than
    .DOC.  This makes viewing the files under the Windows environment more
    friendly as users of MS Word for Windows will not be forced to use Word
    for reading the documentation files which are in text format anyway.
