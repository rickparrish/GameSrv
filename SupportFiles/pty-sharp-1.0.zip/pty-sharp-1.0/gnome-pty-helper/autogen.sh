autoheader
aclocal
automake --add-missing
autoconf
./configure $*