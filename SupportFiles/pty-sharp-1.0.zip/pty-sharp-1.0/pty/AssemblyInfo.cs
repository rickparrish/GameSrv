using System.Reflection;

[assembly: AssemblyDelaySign (false)]
[assembly: AssemblyKeyFile ("pty-sharp.snk")]

[assembly: AssemblyTitle ("Unix Pseudo terminal bindings for Mono")]
[assembly: AssemblyProduct ("Mono")]
[assembly: AssemblyCopyright ("2009 Novell, Inc.")]
[assembly: AssemblyCompany ("Novell, Inc.")]
[assembly: AssemblyCulture ("")]
[assembly: AssemblyConfiguration ("")]

[assembly: AssemblyVersion ("1.0.0.0")]

